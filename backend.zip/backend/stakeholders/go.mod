module stakeholders

go 1.21

require (
	github.com/golang-jwt/jwt/v5 v5.2.1
	github.com/google/uuid v1.3.0
	github.com/gorilla/mux v1.8.0
	github.com/rs/cors v1.11.1
	golang.org/x/crypto v0.12.0
	gorm.io/driver/mysql v1.5.1
	gorm.io/gorm v1.25.4
)

require (
	github.com/go-sql-driver/mysql v1.7.0 // indirect
	github.com/jinzhu/inflection v1.0.0 // indirect
	github.com/jinzhu/now v1.1.5 // indirect
)
