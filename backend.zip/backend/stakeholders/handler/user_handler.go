package handler

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"stakeholders/model"
	"stakeholders/service"
	"strings"
	"errors" 
	"time"

	"github.com/google/uuid" 
	"github.com/gorilla/mux"
	"gorm.io/gorm" 

)

type UserHandler struct {
	service *service.UserService
}

func NewUserHandler(service *service.UserService) *UserHandler {
	return &UserHandler{service: service}
}

func (h *UserHandler) RegisterRoutes(router *mux.Router) {
	router.HandleFunc("/register", h.register).Methods("POST")
	router.HandleFunc("/login", h.login).Methods("POST")
	router.HandleFunc("/block-user/{id}", h.blockUser).Methods("POST")
	router.HandleFunc("/users", h.getAllUsers).Methods("GET")
	// public minimal list of non-admin users for recommendations
	router.HandleFunc("/users/public", h.getPublicUsers).Methods("GET")
	router.HandleFunc("/users/{id}", h.getUserByID).Methods("GET")
}

func (h *UserHandler) RegisterProtectedRoutes(router *mux.Router) {
	router.HandleFunc("/me", h.getMe).Methods("GET")
	router.HandleFunc("/me", h.updateMe).Methods("PUT")
	router.HandleFunc("/upload-profile-picture", h.uploadProfilePicture).Methods("POST")
}

type registerRequest struct {
	Username       string `json:"username"`
	Password       string `json:"password"`
	Email          string `json:"email"`
	Role           string `json:"role"`
	ProfilePicture string `json:"profile_picture"`
	Biography      string `json:"biography"`
	Motto          string `json:"motto"`
}

type loginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

type loginResponse struct {
	User  *model.User `json:"user"`
	Token string      `json:"token"`
}

func (h *UserHandler) register(w http.ResponseWriter, r *http.Request) {
	var req registerRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request format", http.StatusBadRequest)
		return
	}

	user, err := h.service.Register(r.Context(), &service.RegisterRequest{
		Username:       req.Username,
		Password:       req.Password,
		Email:          req.Email,
		Role:           model.Role(req.Role),
		ProfilePicture: req.ProfilePicture,
		Biography:      req.Biography,
		Motto:          req.Motto,
	})
	if err != nil {
		handleServiceError(w, err)
		return
	}
	respondWithJSON(w, http.StatusCreated, user)
}

func (h *UserHandler) login(w http.ResponseWriter, r *http.Request) {
	var req loginRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request format", http.StatusBadRequest)
		return
	}

	user, token, err := h.service.Login(r.Context(), &service.LoginRequest{
		Email:    req.Email,
		Password: req.Password,
	})
	if err != nil {
		handleServiceError(w, err)
		return
	}
	respondWithJSON(w, http.StatusOK, loginResponse{User: user, Token: token})
}

func (h *UserHandler) getMe(w http.ResponseWriter, r *http.Request) {
	userID, ok := userIDFromCtx(r.Context())
	if !ok {
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}
	dto, err := h.service.GetMe(r.Context(), userID)
	if err != nil {
		handleServiceError(w, err)
		return
	}
	respondWithJSON(w, http.StatusOK, dto)
}

func (h *UserHandler) updateMe(w http.ResponseWriter, r *http.Request) {
	userID, ok := userIDFromCtx(r.Context())
	if !ok {
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}
	var req service.UpdateMeRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request format", http.StatusBadRequest)
		return
	}
	dto, err := h.service.UpdateMe(r.Context(), userID, &req)
	if err != nil {
		if strings.Contains(err.Error(), "valid") || strings.Contains(err.Error(), "max length") {
			respondWithError(w, http.StatusBadRequest, err.Error())
			return
		}
		handleServiceError(w, err)
		return
	}
	respondWithJSON(w, http.StatusOK, dto)
}



func (h *UserHandler) blockUser(w http.ResponseWriter, r *http.Request) {
	
	tokenString := r.Header.Get("Authorization")
	if tokenString == "" {
		respondWithError(w, http.StatusUnauthorized, "Missing authorization token")
		return
	}
	tokenString = strings.TrimPrefix(tokenString, "Bearer ")
	claims, err := h.service.ParseToken(tokenString)
	if err != nil {
		respondWithError(w, http.StatusUnauthorized, "Invalid token")
		return
	}
	role, ok := claims["role"].(string)
	if !ok || role != string(model.RoleAdmin) {
		respondWithError(w, http.StatusForbidden, "Only admins can block users")
		return
	}

	vars := mux.Vars(r)
	userIDToBlockStr := vars["id"]
	userIDToBlock, err := uuid.Parse(userIDToBlockStr)
	if err != nil {
		respondWithError(w, http.StatusBadRequest, "Invalid user ID format in URL")
		return
	}

	adminIDStr, _ := claims["user_id"].(string)
	adminID, _ := uuid.Parse(adminIDStr)


	if adminID == userIDToBlock {
		respondWithError(w, http.StatusBadRequest, "Administrator cannot block themselves")
		return
	}

	userToBlock, err := h.service.GetUserByID(r.Context(), userIDToBlock)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			respondWithError(w, http.StatusNotFound, "User with the given ID was not found")
		} else {
			respondWithError(w, http.StatusInternalServerError, "Error while checking user existence")
		}
		return
	}

	/*if userToBlock.Role == model.RoleAdmin {
		respondWithError(w, http.StatusForbidden, "Cannot block another administrator")
		return
	}*/

	if !userToBlock.Activated {
		respondWithError(w, http.StatusConflict, "User is already blocked")
		return
	}

	if err := h.service.BlockUser(r.Context(), userIDToBlock); err != nil {
		handleServiceError(w, err)
		return
	}

	respondWithJSON(w, http.StatusOK, map[string]string{"message": "User blocked successfully"})
}

func (h *UserHandler) getAllUsers(w http.ResponseWriter, r *http.Request) {
	tokenString := r.Header.Get("Authorization")
	if tokenString == "" {
		respondWithError(w, http.StatusUnauthorized, "Missing authorization token")
		return
	}

	tokenString = strings.TrimPrefix(tokenString, "Bearer ")


	claims, err := h.service.ParseToken(tokenString)
	if err != nil {
		respondWithError(w, http.StatusUnauthorized, "Invalid or expired token")
		return
	}

	role, ok := claims["role"].(string)
	if !ok || role != string(model.RoleAdmin) {
		respondWithError(w, http.StatusForbidden, "Forbidden: Administrator access required")
		return
	}

	users, err := h.service.GetAll(r.Context())
	if err != nil {
		log.Printf("Error fetching all users: %v", err)
		respondWithError(w, http.StatusInternalServerError, "Internal server error")
		return
	}

	respondWithJSON(w, http.StatusOK, users)
}

// getPublicUsers returns a minimal list of non-admin users (id and username)
func (h *UserHandler) getPublicUsers(w http.ResponseWriter, r *http.Request) {
	users, err := h.service.GetAll(r.Context())
	if err != nil {
		log.Printf("Error fetching users: %v", err)
		respondWithError(w, http.StatusInternalServerError, "Internal server error")
		return
	}
	// map to minimal DTO and filter non-admin
	type pub struct { ID string `json:"id"`; Username string `json:"username"`; Role model.Role `json:"role"` }
	out := make([]pub, 0, len(users))
	for _, u := range users {
		if u.Role == model.RoleAdmin { continue }
		out = append(out, pub{ ID: u.ID.String(), Username: u.Username, Role: u.Role })
	}
	respondWithJSON(w, http.StatusOK, out)
}

func (h *UserHandler) getUserByID(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	idStr := vars["id"]
	id, err := uuid.Parse(idStr)
	if err != nil {
		respondWithError(w, http.StatusBadRequest, "Invalid user ID")
		return
	}
	user, err := h.service.GetUserByID(r.Context(), id)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			respondWithError(w, http.StatusNotFound, "User not found")
			return
		}
		handleServiceError(w, err)
		return
	}
	respondWithJSON(w, http.StatusOK, user)
}

func handleServiceError(w http.ResponseWriter, err error) {
	switch {
	case strings.Contains(err.Error(), "invalid role"):
		respondWithError(w, http.StatusBadRequest, err.Error())
	case strings.Contains(err.Error(), "username already taken"):
		respondWithError(w, http.StatusConflict, err.Error())
	case strings.Contains(err.Error(), "username already exists"):
		respondWithError(w, http.StatusConflict, err.Error())
	case strings.Contains(err.Error(), "email already registered"):
		respondWithError(w, http.StatusConflict, err.Error())
	case strings.Contains(err.Error(), "password must be"):
		respondWithError(w, http.StatusBadRequest, err.Error())
	case strings.Contains(err.Error(), "invalid credentials"):
		respondWithError(w, http.StatusUnauthorized, err.Error())
	default:
		log.Printf("Internal server error: %v", err)
		respondWithError(w, http.StatusInternalServerError, "Internal server error")
	}
}

func respondWithError(w http.ResponseWriter, code int, message string) {
	respondWithJSON(w, code, map[string]string{"error": message})
}

func respondWithJSON(w http.ResponseWriter, status int, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(data)
}

func userIDFromCtx(ctx context.Context) (uuid.UUID, bool) {
	raw, _ := ctx.Value("user_id").(string)
	id, err := uuid.Parse(raw)
	return id, err == nil
}

func (h *UserHandler) uploadProfilePicture(w http.ResponseWriter, r *http.Request) {
	userID, ok := userIDFromCtx(r.Context())
	if !ok {
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	// Parse multipart form
	err := r.ParseMultipartForm(10 << 20) // 10 MB max
	if err != nil {
		respondWithError(w, http.StatusBadRequest, "Unable to parse form")
		return
	}

	file, handler, err := r.FormFile("profile_picture")
	if err != nil {
		respondWithError(w, http.StatusBadRequest, "Unable to get file from form")
		return
	}
	defer file.Close()

	// Validate file type
	if !strings.HasPrefix(handler.Header.Get("Content-Type"), "image/") {
		respondWithError(w, http.StatusBadRequest, "File must be an image")
		return
	}

	// Create uploads directory if it doesn't exist
	uploadsDir := "/app/uploads"
	if err := os.MkdirAll(uploadsDir, 0755); err != nil {
		log.Printf("Error creating uploads directory: %v", err)
		respondWithError(w, http.StatusInternalServerError, "Unable to create uploads directory")
		return
	}

	// Generate unique filename
	ext := filepath.Ext(handler.Filename)
	if ext == "" {
		ext = ".jpg" // default extension
	}
	filename := fmt.Sprintf("%s_%d%s", userID.String(), time.Now().Unix(), ext)
	filePath := filepath.Join(uploadsDir, filename)

	// Create the file
	dst, err := os.Create(filePath)
	if err != nil {
		log.Printf("Error creating file: %v", err)
		respondWithError(w, http.StatusInternalServerError, "Unable to create file")
		return
	}
	defer dst.Close()

	// Copy file content
	_, err = io.Copy(dst, file)
	if err != nil {
		log.Printf("Error copying file: %v", err)
		respondWithError(w, http.StatusInternalServerError, "Unable to save file")
		return
	}

	// Return the file path that can be used to access the image
	fileURL := fmt.Sprintf("/uploads/%s", filename)
	respondWithJSON(w, http.StatusOK, map[string]string{"file_path": fileURL})
}
