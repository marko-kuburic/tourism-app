import { Routes, Route, Navigate, NavLink, useLocation, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";  
import { getProfile } from "./api";  
import { normalizeRole } from "./roleUtils";
import TourListForTourist from "../tours/TourListForTourist";  // Importiraj komponentu za turiste
import Login from './Login.jsx'
import Register from './Register.jsx'
import Profile from './Profile.jsx'
import Recommendations from './Recommendations.jsx'
import AdminUsers from './AdminUsers.jsx'
import BlogFeed from './blog/BlogFeed.jsx'
import BlogDetails from './blog/BlogDetails.jsx'
import CreateBlog from './blog/CreateBlog.jsx'         // ⟵ DODATO
import ToursList from '../tours/ToursList.jsx'
import CreateTour from '../tours/CreateTour.jsx'
import TourDetails from '../tours/TourDetails.jsx';
import PositionSimulator from '../position/PositionSimulator.jsx';
import AuthorDashboard from '../author/AuthorDashboard.jsx';  // ⟵ DODATO
import MyTours from '../author/MyTours.jsx';  // ⟵ DODATO
import "../../styles/auth.css";
import Cart from '../purchase/Cart';



export default function App() {
  const location = useLocation()
  const navigate = useNavigate()
  const [myRole, setMyRole] = useState(null)
  const [hasToken, setHasToken] = useState(false)

  // Proveri token kada se komponenta mount-uje i oslušni promene
  useEffect(() => {
    const checkToken = () => {
      const token = !!localStorage.getItem('auth_token')
      setHasToken(token)
    }
    
    checkToken() // inicijalna provjera
    
    // Oslušni promjene u localStorage (radi između tab-ova)
    window.addEventListener('storage', checkToken)
    
    // Dodaj custom event za manual trigger (radi u istom tab-u)
    window.addEventListener('auth-changed', checkToken)
    
    return () => {
      window.removeEventListener('storage', checkToken)
      window.removeEventListener('auth-changed', checkToken)
    }
  }, [])

  useEffect(() => {
    if (!hasToken) { 
      setMyRole(null)
      return 
    }
    (async () => {
      try {
        const me = await getProfile()
        const r = (me?.role ?? me?.Role ?? '').toString().toLowerCase()
        setMyRole(r || null)
      } catch {
        setMyRole(null)
      }
    })()
  }, [hasToken])

  useEffect(() => {
    if (hasToken && myRole === 'admin' &&
        (location.pathname === '/profile' || location.pathname === '/recommendations')) {
      navigate('/admin/users', { replace: true })
    }
  }, [hasToken, myRole, location.pathname, navigate])

  function onLogout() {
    try { localStorage.removeItem('auth_token') } catch {}
    setMyRole(null)
    setHasToken(false)  // Eksplicitno resetuj hasToken
    
    // Trigger custom event
    window.dispatchEvent(new Event('auth-changed'))
    
    navigate('/login', { replace: true })
  }

  const isAdmin = myRole === 'admin'
  const isTourist = myRole === 'tourist'
  const isGuide = myRole === 'guide'

  return (
    <div className="auth-wrap">
      <div className={`card ${isAdmin ? 'card-wide' : ''}`}>

        {/* Header row */}
        <div className="card-header" style={{display:'flex', alignItems:'center', gap:12}}>
          <h2 className="title" style={{margin:0, lineHeight:1}}>Welcome</h2>
        </div>

        {/* Nav row */}
        <nav className="tabs"
             style={{display:'flex', alignItems:'center', gap:12, marginTop:12}}>
          {!hasToken ? (
            <>
              <Nav className="tab" to="/login">Login</Nav>
              <Nav className="tab" to="/register">Register</Nav>
            </>
          ) : (
            <>
              {isAdmin ? (
                <Nav className="tab" to="/admin/users">Users</Nav>
              ) : (
                <>
                  <Nav className="tab" to="/profile">Profile</Nav>
                  <Nav className="tab" to="/recommendations">Recommendations</Nav>
                  <Nav className="tab" to="/blog" end>Blog</Nav>
                  <Nav className="tab" to="/blog/new">Create Blog</Nav>
                </>
              )}


              {/* Hide Tours tab completely for admin */}
              {!isAdmin && (
                <Nav className="tab" to="/tours" end>Tours</Nav>
              )}
              {isTourist && (
                <Nav className="tab" to="/cart">Cart</Nav>
              )}


              {/* Create Tour vidi samo guide ili admin */}
              {(isGuide) && (
                <Nav className="tab" to="/tours/new">Create Tour</Nav>
              )}


              <span style={{marginLeft:'auto'}} />
              <button className="button" style={{lineHeight:1}} onClick={onLogout}>
                Logout
              </button>
            </>
          )}
        </nav>

        {/* Content */}
        <div className="grid">
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            <Route path="/profile" element={<Profile />} />
            <Route path="/recommendations" element={<Recommendations />} />
            <Route path="/blog" element={<BlogFeed />} />
            <Route path="/blog/new" element={<CreateBlog />} />   {/* ⟵ DODATO */}
            <Route path="/blog/:id" element={<BlogDetails />} />

            <Route path="/cart" element={<Cart />} />
            
            {/* Author/Guide rute */}
            <Route 
              path="/author" 
              element={
                !hasToken ? <Navigate to="/login" replace /> :
                isGuide ? <AuthorDashboard /> : 
                isAdmin ? <Navigate to="/admin/users" replace /> :
                <Navigate to="/tours" replace />
              } 
            />
            <Route 
              path="/author/tours" 
              element={
                !hasToken ? <Navigate to="/login" replace /> :
                isGuide ? <MyTours /> : 
                isAdmin ? <Navigate to="/admin/users" replace /> :
                <Navigate to="/tours" replace />
              } 
            />
            
            {/* Admin rute – štitimo jednostavnim guardom */}
            <Route
              path="/admin/users"
              element={isAdmin ? <AdminUsers /> : <Navigate to="/admin/users" replace />}
            />

            {/* Ture: admin ne sme da vidi ni listu ni detalje */}
            <Route
              path="/tours"
              element={
                isAdmin
                  ? <Navigate to="/admin/users" replace />
                  : (isTourist ? <TourListForTourist /> : <ToursList />)
              }
            />
            <Route
              path="/tours/:id"
              element={
                isAdmin
                  ? <Navigate to="/admin/users" replace />
                  : <TourDetails />
              }
            />

            <Route path="/tours/new" element={<CreateTour />} />
            <Route path="/position-simulator" element={<PositionSimulator/>} />

            {/* Dodaj eksplicitne rute za home stranice */}
            <Route 
              path="/" 
              element={
                !hasToken ? <Navigate to="/login" replace /> :
                isAdmin ? <Navigate to="/admin/users" replace /> :
                isGuide ? <Navigate to="/author" replace /> :
                isTourist ? <Navigate to="/tours" replace /> :
                <Navigate to="/login" replace />
              } 
            />

            <Route
              path="*"
              element={
                !hasToken ? <Navigate to="/login" replace /> :
                isAdmin ? <Navigate to="/admin/users" replace /> :
                isGuide ? <Navigate to="/author" replace /> :
                isTourist ? <Navigate to="/tours" replace /> :
                <Navigate to="/login" replace />
              }
            />
          </Routes>
        </div>
      </div>
    </div>
  )
}

/* Small helper so tabs get an active class and align nicely */
function Nav({ to, end, className = 'tab', children }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        `${className} ${isActive ? 'tab--active' : ''}`
      }
    >
      {children}
    </NavLink>
  )
}
